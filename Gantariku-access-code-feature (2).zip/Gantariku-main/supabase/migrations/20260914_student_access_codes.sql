-- Gantariku: kode akses siswa untuk onboarding akun orang tua
-- Jalankan di Supabase SQL Editor setelah backup/staging verification.
-- Migration ini tidak mengubah relasi orang_tua_id yang sudah ada.

create extension if not exists pgcrypto;

alter table public.siswa
  add column if not exists kode_akses text;

-- Mengisi record lama yang belum memiliki kode.
update public.siswa
set kode_akses = 'GTR-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 8))
where kode_akses is null or btrim(kode_akses) = '';

-- Kode harus unik dan memiliki format aplikasi.
alter table public.siswa
  drop constraint if exists siswa_kode_akses_format_check;

alter table public.siswa
  add constraint siswa_kode_akses_format_check
  check (
    kode_akses is null
    or kode_akses ~ '^GTR-[A-Z2-9]{8}$'
  );

create unique index if not exists siswa_kode_akses_unique_idx
  on public.siswa (kode_akses)
  where kode_akses is not null and btrim(kode_akses) <> '';

comment on column public.siswa.kode_akses is
  'Kode unik sekali pakai/terkendali untuk menghubungkan siswa ke akun orang tua.';

-- RLS note:
-- 1. Admin boleh membaca dan memperbarui kode.
-- 2. Guru tidak perlu membaca kode.
-- 3. Orang tua tidak perlu membaca kode siswa lain.
-- 4. RPC hubungkan_anak(p_kode_akses) harus memvalidasi kode,
--    memastikan siswa belum memiliki orang_tua_id, lalu mengisi
--    orang_tua_id berdasarkan auth.uid().
-- 5. Pertimbangkan menghapus/mengosongkan kode setelah berhasil dipakai
--    jika kode memang dimaksudkan sekali pakai.
